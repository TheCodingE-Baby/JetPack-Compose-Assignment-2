package com.example.jetpackcomposewithretrofitandroom.data

data class ToDoModel(
    val toDoId: Int,
    val toDoName: String,
    val isDone: Boolean
)